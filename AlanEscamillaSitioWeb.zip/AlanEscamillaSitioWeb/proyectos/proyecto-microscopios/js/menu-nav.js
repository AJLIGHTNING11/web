// JavaScript Document
const root = document.documentElement; 
let choose_font = document.querySelectorAll(".select_font .ff li");

choose_font.forEach(i => {
  i.addEventListener("click", () => {
      root.style.setProperty("--main-font",`${i.getAttribute("data-font")}`,null);
  });
  
  
});

let ten_items = document.querySelectorAll(".ten li"),
  wrap_ten_items = document.querySelector(".ten"),
  bg = document.querySelector(".move_bg");

ten_items.forEach(i => {
  i.addEventListener("mouseenter", () => {
    bg.style.opacity = "1";
    i.style.color = "#000";
    bg.style.width = `${i.offsetWidth}px`;
    bg.style.height = `3px`;
    bg.style.left = `${i.getBoundingClientRect().left -
      wrap_ten_items.getBoundingClientRect().left}px`;
    bg.style.top = `${i.getBoundingClientRect().top -
      wrap_ten_items.getBoundingClientRect().top + i.offsetHeight}px`;

    i.addEventListener("mouseleave", () => {
      i.style.color = "#333";
    });

    wrap_ten_items.addEventListener("mouseleave", () => {
      bg.style.opacity = "0";
    });
  });
});
